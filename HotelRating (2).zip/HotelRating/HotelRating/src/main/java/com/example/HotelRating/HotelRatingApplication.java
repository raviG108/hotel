package com.example.HotelRating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelRatingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelRatingApplication.class, args);
	}

}
