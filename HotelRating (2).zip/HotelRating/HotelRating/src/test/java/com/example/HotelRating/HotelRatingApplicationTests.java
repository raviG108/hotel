package com.example.HotelRating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelRatingApplicationTests {

	@Test
	void contextLoads() {
	}

}
